﻿namespace SerialLogger1
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.cb_PARITY = new System.Windows.Forms.ComboBox();
            this.cb_STOPBITS = new System.Windows.Forms.ComboBox();
            this.cb_BITS = new System.Windows.Forms.ComboBox();
            this.cb_BAUDRATE = new System.Windows.Forms.ComboBox();
            this.cb_COMPORT = new System.Windows.Forms.ComboBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.lb_STATUS = new System.Windows.Forms.Label();
            this.progressBar1 = new System.Windows.Forms.ProgressBar();
            this.btn_CLOSE = new System.Windows.Forms.Button();
            this.btn_OPEN = new System.Windows.Forms.Button();
            this.serialPort1 = new System.IO.Ports.SerialPort(this.components);
            this.chb_DTR = new System.Windows.Forms.CheckBox();
            this.chb_RTS = new System.Windows.Forms.CheckBox();
            this.lb_DataLength = new System.Windows.Forms.Label();
            this.lb_DATA_LENGTH = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.tb_RECEIVEDDATA = new System.Windows.Forms.TextBox();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.btn_CLEAR = new System.Windows.Forms.Button();
            this.chb_SAVE_TO_FILE = new System.Windows.Forms.CheckBox();
            this.btn_FILE_PATH = new System.Windows.Forms.Button();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.label6 = new System.Windows.Forms.Label();
            this.tb_PACK_LENGTH = new System.Windows.Forms.TextBox();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.cb_PARITY);
            this.groupBox1.Controls.Add(this.cb_STOPBITS);
            this.groupBox1.Controls.Add(this.cb_BITS);
            this.groupBox1.Controls.Add(this.cb_BAUDRATE);
            this.groupBox1.Controls.Add(this.cb_COMPORT);
            this.groupBox1.Location = new System.Drawing.Point(12, 29);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(219, 205);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "COM Port Settings";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(41, 159);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(44, 17);
            this.label5.TabIndex = 9;
            this.label5.Text = "Parity";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(21, 129);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(64, 17);
            this.label4.TabIndex = 8;
            this.label4.Text = "Stop Bits";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(54, 99);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(31, 17);
            this.label3.TabIndex = 7;
            this.label3.Text = "BIts";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(10, 69);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(75, 17);
            this.label2.TabIndex = 6;
            this.label2.Text = "Baud Rate";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(16, 39);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(69, 17);
            this.label1.TabIndex = 5;
            this.label1.Text = "COM Port";
            // 
            // cb_PARITY
            // 
            this.cb_PARITY.FormattingEnabled = true;
            this.cb_PARITY.Items.AddRange(new object[] {
            "None",
            "Odd",
            "Even"});
            this.cb_PARITY.Location = new System.Drawing.Point(88, 156);
            this.cb_PARITY.Name = "cb_PARITY";
            this.cb_PARITY.Size = new System.Drawing.Size(121, 24);
            this.cb_PARITY.TabIndex = 4;
            this.cb_PARITY.Text = "None";
            // 
            // cb_STOPBITS
            // 
            this.cb_STOPBITS.FormattingEnabled = true;
            this.cb_STOPBITS.Items.AddRange(new object[] {
            "1",
            "2"});
            this.cb_STOPBITS.Location = new System.Drawing.Point(88, 126);
            this.cb_STOPBITS.Name = "cb_STOPBITS";
            this.cb_STOPBITS.Size = new System.Drawing.Size(121, 24);
            this.cb_STOPBITS.TabIndex = 3;
            this.cb_STOPBITS.Text = "1";
            // 
            // cb_BITS
            // 
            this.cb_BITS.FormattingEnabled = true;
            this.cb_BITS.Items.AddRange(new object[] {
            "6",
            "7",
            "8"});
            this.cb_BITS.Location = new System.Drawing.Point(88, 96);
            this.cb_BITS.Name = "cb_BITS";
            this.cb_BITS.Size = new System.Drawing.Size(121, 24);
            this.cb_BITS.TabIndex = 2;
            this.cb_BITS.Text = "8";
            // 
            // cb_BAUDRATE
            // 
            this.cb_BAUDRATE.FormattingEnabled = true;
            this.cb_BAUDRATE.Items.AddRange(new object[] {
            "2400",
            "4800",
            "9600",
            "19200",
            "34600",
            "56700",
            "78800",
            "115200",
            "230400",
            "250000"});
            this.cb_BAUDRATE.Location = new System.Drawing.Point(88, 66);
            this.cb_BAUDRATE.Name = "cb_BAUDRATE";
            this.cb_BAUDRATE.Size = new System.Drawing.Size(121, 24);
            this.cb_BAUDRATE.TabIndex = 1;
            this.cb_BAUDRATE.Text = "115200";
            // 
            // cb_COMPORT
            // 
            this.cb_COMPORT.FormattingEnabled = true;
            this.cb_COMPORT.Location = new System.Drawing.Point(88, 36);
            this.cb_COMPORT.Name = "cb_COMPORT";
            this.cb_COMPORT.Size = new System.Drawing.Size(121, 24);
            this.cb_COMPORT.TabIndex = 0;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.groupBox5);
            this.groupBox2.Controls.Add(this.progressBar1);
            this.groupBox2.Controls.Add(this.btn_CLOSE);
            this.groupBox2.Controls.Add(this.btn_OPEN);
            this.groupBox2.Location = new System.Drawing.Point(12, 299);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(209, 152);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.lb_STATUS);
            this.groupBox5.Location = new System.Drawing.Point(94, 14);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(109, 95);
            this.groupBox5.TabIndex = 4;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Status";
            // 
            // lb_STATUS
            // 
            this.lb_STATUS.AutoSize = true;
            this.lb_STATUS.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lb_STATUS.Location = new System.Drawing.Point(38, 44);
            this.lb_STATUS.Name = "lb_STATUS";
            this.lb_STATUS.Size = new System.Drawing.Size(38, 17);
            this.lb_STATUS.TabIndex = 0;
            this.lb_STATUS.Text = "OFF";
            this.lb_STATUS.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // progressBar1
            // 
            this.progressBar1.Location = new System.Drawing.Point(13, 123);
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new System.Drawing.Size(181, 23);
            this.progressBar1.TabIndex = 3;
            // 
            // btn_CLOSE
            // 
            this.btn_CLOSE.Location = new System.Drawing.Point(13, 66);
            this.btn_CLOSE.Name = "btn_CLOSE";
            this.btn_CLOSE.Size = new System.Drawing.Size(75, 43);
            this.btn_CLOSE.TabIndex = 1;
            this.btn_CLOSE.Text = "CLOSE";
            this.btn_CLOSE.UseVisualStyleBackColor = true;
            this.btn_CLOSE.Click += new System.EventHandler(this.btn_CLOSE_Click);
            // 
            // btn_OPEN
            // 
            this.btn_OPEN.Location = new System.Drawing.Point(13, 21);
            this.btn_OPEN.Name = "btn_OPEN";
            this.btn_OPEN.Size = new System.Drawing.Size(75, 43);
            this.btn_OPEN.TabIndex = 0;
            this.btn_OPEN.Text = "OPEN";
            this.btn_OPEN.UseVisualStyleBackColor = true;
            this.btn_OPEN.Click += new System.EventHandler(this.btn_OPEN_Click);
            // 
            // serialPort1
            // 
            this.serialPort1.DataReceived += new System.IO.Ports.SerialDataReceivedEventHandler(this.serialPort1_DataReceived);
            // 
            // chb_DTR
            // 
            this.chb_DTR.AutoSize = true;
            this.chb_DTR.Location = new System.Drawing.Point(12, 240);
            this.chb_DTR.Name = "chb_DTR";
            this.chb_DTR.Size = new System.Drawing.Size(59, 21);
            this.chb_DTR.TabIndex = 4;
            this.chb_DTR.Text = "DTR";
            this.chb_DTR.UseVisualStyleBackColor = true;
            this.chb_DTR.CheckedChanged += new System.EventHandler(this.chb_DTR_CheckedChanged);
            // 
            // chb_RTS
            // 
            this.chb_RTS.AutoSize = true;
            this.chb_RTS.Location = new System.Drawing.Point(123, 240);
            this.chb_RTS.Name = "chb_RTS";
            this.chb_RTS.Size = new System.Drawing.Size(58, 21);
            this.chb_RTS.TabIndex = 5;
            this.chb_RTS.Text = "RTS";
            this.chb_RTS.UseVisualStyleBackColor = true;
            this.chb_RTS.CheckedChanged += new System.EventHandler(this.chb_RTS_CheckedChanged);
            // 
            // lb_DataLength
            // 
            this.lb_DataLength.AutoSize = true;
            this.lb_DataLength.Location = new System.Drawing.Point(6, 18);
            this.lb_DataLength.Name = "lb_DataLength";
            this.lb_DataLength.Size = new System.Drawing.Size(90, 17);
            this.lb_DataLength.TabIndex = 11;
            this.lb_DataLength.Text = "Data Length:";
            this.lb_DataLength.Click += new System.EventHandler(this.label6_Click);
            // 
            // lb_DATA_LENGTH
            // 
            this.lb_DATA_LENGTH.AutoSize = true;
            this.lb_DATA_LENGTH.Location = new System.Drawing.Point(141, 18);
            this.lb_DATA_LENGTH.Name = "lb_DATA_LENGTH";
            this.lb_DATA_LENGTH.Size = new System.Drawing.Size(16, 17);
            this.lb_DATA_LENGTH.TabIndex = 12;
            this.lb_DATA_LENGTH.Text = "0";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.lb_DataLength);
            this.groupBox4.Controls.Add(this.lb_DATA_LENGTH);
            this.groupBox4.Location = new System.Drawing.Point(19, 320);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(252, 38);
            this.groupBox4.TabIndex = 14;
            this.groupBox4.TabStop = false;
            // 
            // tb_RECEIVEDDATA
            // 
            this.tb_RECEIVEDDATA.Location = new System.Drawing.Point(6, 21);
            this.tb_RECEIVEDDATA.Multiline = true;
            this.tb_RECEIVEDDATA.Name = "tb_RECEIVEDDATA";
            this.tb_RECEIVEDDATA.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.tb_RECEIVEDDATA.Size = new System.Drawing.Size(290, 293);
            this.tb_RECEIVEDDATA.TabIndex = 15;
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.chb_SAVE_TO_FILE);
            this.groupBox6.Controls.Add(this.btn_CLEAR);
            this.groupBox6.Controls.Add(this.btn_FILE_PATH);
            this.groupBox6.Controls.Add(this.groupBox4);
            this.groupBox6.Controls.Add(this.tb_RECEIVEDDATA);
            this.groupBox6.Location = new System.Drawing.Point(237, 29);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(302, 426);
            this.groupBox6.TabIndex = 16;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Received Data";
            // 
            // btn_CLEAR
            // 
            this.btn_CLEAR.Location = new System.Drawing.Point(19, 372);
            this.btn_CLEAR.Name = "btn_CLEAR";
            this.btn_CLEAR.Size = new System.Drawing.Size(148, 48);
            this.btn_CLEAR.TabIndex = 16;
            this.btn_CLEAR.Text = "Clear";
            this.btn_CLEAR.UseVisualStyleBackColor = true;
            this.btn_CLEAR.Click += new System.EventHandler(this.btn_CLEAR_Click);
            // 
            // chb_SAVE_TO_FILE
            // 
            this.chb_SAVE_TO_FILE.AutoSize = true;
            this.chb_SAVE_TO_FILE.Location = new System.Drawing.Point(187, 401);
            this.chb_SAVE_TO_FILE.Name = "chb_SAVE_TO_FILE";
            this.chb_SAVE_TO_FILE.Size = new System.Drawing.Size(109, 21);
            this.chb_SAVE_TO_FILE.TabIndex = 17;
            this.chb_SAVE_TO_FILE.Text = "Save To File";
            this.chb_SAVE_TO_FILE.UseVisualStyleBackColor = true;
            // 
            // btn_FILE_PATH
            // 
            this.btn_FILE_PATH.Location = new System.Drawing.Point(187, 372);
            this.btn_FILE_PATH.Name = "btn_FILE_PATH";
            this.btn_FILE_PATH.Size = new System.Drawing.Size(109, 23);
            this.btn_FILE_PATH.TabIndex = 16;
            this.btn_FILE_PATH.Text = "File Path";
            this.btn_FILE_PATH.UseVisualStyleBackColor = true;
            this.btn_FILE_PATH.Click += new System.EventHandler(this.btn_FILE_PATH_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(12, 279);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(87, 17);
            this.label6.TabIndex = 17;
            this.label6.Text = "Pack Length";
            // 
            // tb_PACK_LENGTH
            // 
            this.tb_PACK_LENGTH.Location = new System.Drawing.Point(105, 274);
            this.tb_PACK_LENGTH.Name = "tb_PACK_LENGTH";
            this.tb_PACK_LENGTH.Size = new System.Drawing.Size(100, 22);
            this.tb_PACK_LENGTH.TabIndex = 18;
            this.tb_PACK_LENGTH.TextChanged += new System.EventHandler(this.tb_PACK_LENGTH_TextChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(562, 546);
            this.Controls.Add(this.tb_PACK_LENGTH);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.groupBox6);
            this.Controls.Add(this.chb_RTS);
            this.Controls.Add(this.chb_DTR);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.DoubleBuffered = true;
            this.Name = "Form1";
            this.Text = "COM PORT TOOL by DMYTRO";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cb_PARITY;
        private System.Windows.Forms.ComboBox cb_STOPBITS;
        private System.Windows.Forms.ComboBox cb_BITS;
        private System.Windows.Forms.ComboBox cb_BAUDRATE;
        private System.Windows.Forms.ComboBox cb_COMPORT;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.ProgressBar progressBar1;
        private System.Windows.Forms.Button btn_CLOSE;
        private System.Windows.Forms.Button btn_OPEN;
        private System.IO.Ports.SerialPort serialPort1;
        private System.Windows.Forms.CheckBox chb_DTR;
        private System.Windows.Forms.CheckBox chb_RTS;
        private System.Windows.Forms.Label lb_DataLength;
        private System.Windows.Forms.Label lb_DATA_LENGTH;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Label lb_STATUS;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TextBox tb_RECEIVEDDATA;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.CheckBox chb_SAVE_TO_FILE;
        private System.Windows.Forms.Button btn_FILE_PATH;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private System.Windows.Forms.Button btn_CLEAR;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox tb_PACK_LENGTH;
    }
}

