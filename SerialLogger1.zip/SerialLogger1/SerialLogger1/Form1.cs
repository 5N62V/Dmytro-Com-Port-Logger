﻿using System;
using System.IO;
using System.IO.Ports;
using System.Windows.Forms;

namespace SerialLogger1
{
    public partial class Form1 : Form
    {

        string dataOUT;
        string Sendwith;
        string dataIn;
        int expectedBytesToRead;
        string path;
        int receivedDataLength = 0;
        public Form1()
        {
            InitializeComponent();
            saveFileDialog1.Filter = "Text files(*.txt)|*.txt|All files(*.*)|*.*";
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            string[] ports = SerialPort.GetPortNames();
            cb_COMPORT.Items.AddRange(ports);

            chb_RTS.Checked = false;
            chb_DTR.Checked = false;
            serialPort1.DtrEnable = false;
            serialPort1.RtsEnable = false;
            chb_SAVE_TO_FILE.Enabled = false;
            tb_PACK_LENGTH.Text = "10";
            expectedBytesToRead = Convert.ToInt32(tb_PACK_LENGTH.Text);
            btn_CLOSE.Enabled = false;
            lb_DATA_LENGTH.Text = receivedDataLength.ToString();
        }

        private void btn_OPEN_Click(object sender, EventArgs e)
        {
            try
            {

                serialPort1.PortName = cb_COMPORT.Text;
                serialPort1.BaudRate = Convert.ToInt32(cb_BAUDRATE.Text);
                serialPort1.DataBits = Convert.ToInt32(cb_BITS.Text);
                serialPort1.StopBits = (StopBits)Convert.ToInt32(cb_STOPBITS.Text);
                serialPort1.Parity = (Parity)Enum.Parse(typeof(Parity), cb_PARITY.Text);
                serialPort1.ReceivedBytesThreshold = 10;
                serialPort1.Open();
                progressBar1.Value = 100;
                serialPort1.DiscardInBuffer();
                if (serialPort1.IsOpen)
                {
                    lb_STATUS.Text = "ON";
                    tb_PACK_LENGTH.Enabled = false;
                    btn_OPEN.Enabled = false;
                    btn_CLOSE.Enabled = true;
                }
            }

            catch (Exception err)
            {
                MessageBox.Show(err.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }


        }

        private void btn_CLOSE_Click(object sender, EventArgs e)
        {
            if (serialPort1.IsOpen)
            {
                serialPort1.Close();
                progressBar1.Value = 0;
                lb_STATUS.Text = "OFF";
                tb_PACK_LENGTH.Enabled = true;
                btn_CLOSE.Enabled = false;
                btn_OPEN.Enabled = true;
            }

        }


        private void chb_DTR_CheckedChanged(object sender, EventArgs e)
        {
            if (chb_DTR.Checked) serialPort1.DtrEnable = true;
            else serialPort1.DtrEnable = false;
        }



        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void chb_RTS_CheckedChanged(object sender, EventArgs e)
        {
            if (chb_RTS.Checked) serialPort1.RtsEnable = true;
            else serialPort1.RtsEnable = false;
        }



        private void serialPort1_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            if (serialPort1.IsOpen)
            {
                if (serialPort1.BytesToRead < expectedBytesToRead)
                    return;
            }
            receivedDataLength += serialPort1.BytesToRead;
            dataIn = serialPort1.ReadExisting();
            if (serialPort1.BytesToRead > 0)
            {
                serialPort1.DiscardInBuffer();
            }

            if (chb_SAVE_TO_FILE.Checked)
            {
                using (StreamWriter stream = new StreamWriter(path, true)) stream.WriteLine(dataIn);
            }

            this.Invoke(new EventHandler(showData));
            lb_DATA_LENGTH.Text = receivedDataLength.ToString();
        }

        private void showData(object sender, EventArgs e)
        {
            tb_RECEIVEDDATA.Text = dataIn;
            dataIn = "";
        }

        private void btn_FILE_PATH_Click(object sender, EventArgs e)
        {
            if (saveFileDialog1.ShowDialog() == DialogResult.Cancel)
                return;

            path = saveFileDialog1.FileName;
            chb_SAVE_TO_FILE.Enabled = true;
        }

        private void btn_CLEAR_Click(object sender, EventArgs e)
        {
            tb_RECEIVEDDATA.Text = "";
        }

        private void tb_PACK_LENGTH_TextChanged(object sender, EventArgs e)
        {
            expectedBytesToRead = Convert.ToInt32(tb_PACK_LENGTH.Text);
        }
    }
}
